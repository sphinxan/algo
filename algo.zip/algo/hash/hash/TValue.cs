﻿namespace hash
{
    internal class TValue
    {
    }
}